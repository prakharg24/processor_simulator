function instrdisplay(){
document.getElementById('text2885').textContent="IF NOP ";
document.getElementById('text2889').textContent="ID NOP";
document.getElementById('text2893').textContent="EX NOP";
document.getElementById('text2897').textContent="MEM NOP";
document.getElementById('text2901').textContent="WB slti";

}