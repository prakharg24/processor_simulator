#ifndef BIG_H_   /* Include guard */
#define BIG_H_

void setlat(int lat);
void setfreq(double freq);
void setfile(FILE *sd,FILE *df);
void mainkaam(FILE *reader);



#endif // BIG_H_
