assumptions:
1. chk ek baar jump instruction se next pc is stored in rf31.
2. max pc value allowed is 16386
3. bsize power of 2
4. bsize > 4
5. there is different cache for data and instructions always
